package com.example.worldclockwallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(48,80,48,48);
        TextView t = new TextView(this); t.setText("World Clock Live Wallpaper\\n\\n사진 배경 + 실시간 시계"); t.setTextSize(22); box.addView(t);
        Button set = new Button(this); set.setText("라이브 배경화면으로 설정"); set.setOnClickListener(v -> {
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new ComponentName(this, WorldClockWallpaperService.class));
            startActivity(i);
        }); box.addView(set); setContentView(box);
    }
}
