package com.example.worldclockwallpaper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class WorldClockWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new ClockEngine(); }

    class ClockEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final String[] zones = {
                "Asia/Seoul", "America/Mexico_City", "Europe/Madrid",
                "America/Tegucigalpa", "America/Bogota", "America/Sao_Paulo"
        };
        private final String[] names = {
                "Seoul", "Mexico City", "Madrid", "Tegucigalpa", "Bogota", "Sao Paulo"
        };
        private Bitmap background;
        private boolean visible;
        private int width, height;

        private final Runnable tick = new Runnable() {
            @Override public void run() {
                drawFrame();
                if (visible) handler.postDelayed(this, 1000L);
            }
        };

        ClockEngine() {
            background = BitmapFactory.decodeResource(getResources(), R.drawable.world_clock_background);
            paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
            paint.setShadowLayer(6f, 0f, 2f, Color.BLACK);
        }

        @Override public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            visible = true;
            drawFrame();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w; height = h;
            drawFrame();
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(tick);
            if (visible) {
                drawFrame();
                handler.postDelayed(tick, 1000L);
            }
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(tick);
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(tick);
            if (background != null && !background.isRecycled()) background.recycle();
            super.onDestroy();
        }

        private void drawFrame() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                width = canvas.getWidth();
                height = canvas.getHeight();

                paint.clearShadowLayer();
                if (background != null && !background.isRecycled()) {
                    Rect src = new Rect(0, 0, background.getWidth(), background.getHeight());
                    Rect dst = new Rect(0, 0, width, height);
                    canvas.drawBitmap(background, src, dst, paint);
                } else {
                    canvas.drawColor(Color.BLACK);
                }

                paint.setColor(Color.WHITE);
                paint.setShadowLayer(7f, 0f, 2f, Color.BLACK);
                paint.setTextAlign(Paint.Align.LEFT);

                float margin = Math.max(24f, width * 0.055f);
                float titleSize = Math.max(25f, width * 0.052f);
                float rowSize = Math.max(17f, width * 0.031f);
                float y = height * 0.70f;

                for (int i = 0; i < names.length; i++) {
                    TimeZone tz = TimeZone.getTimeZone(zones[i]);
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss", Locale.US);
                    format.setTimeZone(tz);
                    String line = names[i] + "  " + format.format(new Date());
                    paint.setTextSize(i == 0 ? titleSize : rowSize);
                    canvas.drawText(line, margin, y, paint);
                    y += paint.getTextSize() * 1.42f;
                }
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }
    }
}
