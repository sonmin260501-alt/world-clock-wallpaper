Galaxy S26용 World Clock Live Wallpaper

구성:
- 사용자가 이전에 만든 세계시계 배경 이미지 포함
- Android WallpaperService 기반 실제 라이브 배경화면
- 매초 갱신되는 실시간 시계: Seoul / Mexico City / Madrid / Tegucigalpa / Bogotá / São Paulo
- 앱 실행 후 '라이브 배경화면으로 설정' 버튼으로 시스템 선택 화면 진입

빌드:
1. Android Studio에서 이 폴더를 열기
2. Gradle JDK 21 사용
3. Gradle 8.11.1 + Android Gradle Plugin 8.11.1
4. Build > Build APK(s)
5. 생성 APK: app/build/outputs/apk/debug/app-debug.apk

S26 설정:
1. APK 설치
2. 앱 실행
3. '라이브 배경화면으로 설정' 터치
4. 미리보기 화면에서 '배경화면 설정'

또는: 설정 > 배경화면 및 스타일 > 배경화면 변경 > 라이브 배경화면 > World Clock
